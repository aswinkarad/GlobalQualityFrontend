<template>
  <v-container class="main-container" fluid>
    <v-breadcrumbs :items="breadcrumbs" class="breadcrumbs-container">
      <template v-slot:divider>
        <v-icon color="white">mdi-chevron-right</v-icon>
      </template>
      <template v-slot:item="{ item }">
        <v-breadcrumbs-item :href="item.href" :disabled="item.disabled" class="custom-breadcrumb-item">
          {{ item.text }}
        </v-breadcrumbs-item>
      </template>
    </v-breadcrumbs>

    <v-card class="detail-card mt-6 rounded-lg pa-6" elevation="8">
      <v-card-title class="card-title">
        Service Request Details
      </v-card-title>
      <v-divider class="card-divider"></v-divider>
      <v-row class="detail-row">
        <v-col cols="12" md="4" class="detail-column">
          <p class="detail-item"><strong>Client Name:</strong> <span class="detail-value">{{
              editServicetValue.sale?.client?.name || 'N/A' }}</span></p>
          <p class="detail-item"><strong>Serial Number:</strong> <span class="detail-value">{{
              editServicetValue.sale?.serialNo || 'N/A' }}</span></p>
          <p class="detail-item"><strong>Machine Name:</strong> <span class="detail-value">{{
              editServicetValue.sale?.equipment?.equipmentName || 'N/A' }}</span></p>
          <p class="detail-item"><strong>Call Register Date:</strong> <span class="detail-value">{{
              editServicetValue.callRegisterDate?.split('T')[0] || 'N/A' }}</span></p>
          <p class="detail-item"><strong>Call Handle:</strong> <span class="detail-value">{{
              editServicetValue.call_handle?.callHandle || 'N/A' }}</span></p>
          <p class="detail-item"><strong>Priority:</strong> <span class="detail-value">{{
              editServicetValue.priority?.priority || 'N/A' }}</span></p>
          <p class="detail-item"><strong>Service Type:</strong> <span class="detail-value">{{
              editServicetValue.service_type?.type || 'N/A' }}</span></p>
        </v-col>
        <v-col cols="12" md="4" class="detail-column">
          <p class="detail-item"><strong>City:</strong> <span class="detail-value">{{
              editServicetValue.sale?.client?.city?.city || 'N/A' }}</span></p>
          <p class="detail-item"><strong>Working Condition:</strong> <span class="detail-value">{{
              editServicetValue.working_condition?.workingCondition || 'N/A' }}</span></p>
          <p class="detail-item"><strong>Assigned To:</strong> <span class="detail-value">{{
              editServicetValue.user?.username || 'N/A' }}</span></p>
          <p class="detail-item"><strong>Service By:</strong> <span class="detail-value">{{ editServicetValue.service_by
              || 'N/A' }}</span></p>
          <p class="detail-item"><strong>Request Type:</strong> <span class="detail-value">{{
              editServicetValue.request_type?.type || 'N/A' }}</span></p>
        </v-col>
        <v-col cols="12" md="4" class="detail-column">
          <p class="detail-item"><strong>Status:</strong>
            <v-chip :color="getStatusColor(editServicetValue.working_status?.workingStatus)" class="status-chip">
              {{ editServicetValue.working_status?.workingStatus || 'N/A' }}
            </v-chip>
          </p>
          <p class="detail-item"><strong>Created At:</strong> <span class="detail-value">{{
              editServicetValue.createdAt?.split('T')[0] || 'N/A' }}</span></p>
          <p class="detail-item"><strong>Updated At:</strong> <span class="detail-value">{{
              editServicetValue.updatedAt?.split('T')[0] || 'N/A' }}</span></p>
          <p class="detail-item"><strong>Problem Description:</strong> <span class="detail-value">{{
              editServicetValue.description || 'N/A' }}</span></p>
          <p class="detail-item"><strong>Solution Provided:</strong> <span class="detail-value">{{
              editServicetValue.solutionProvided || 'N/A' }}</span></p>
          <p class="detail-item"><strong>Is Approved by CEO:</strong> <span class="detail-value">{{
              editServicetValue.isApprovedByCEO ? 'Yes' : 'No' }}</span></p>
        </v-col>
      </v-row>
    </v-card>

    <v-card class="detail-card mt-6 rounded-lg pa-6" elevation="8">
      <v-card-title class="card-title">
        <v-icon left color="#4d90fe">mdi-file-document-multiple-outline</v-icon>
        Documents
      </v-card-title>
      <v-divider class="card-divider"></v-divider>
      <v-row>
        <v-col cols="12">
          <div v-if="processedDocuments && processedDocuments.length > 0">
            <v-list dense class="document-list">
              <v-list-item v-for="(doc, docIndex) in processedDocuments" :key="'doc-' + docIndex"
                class="document-list-item">
                <template v-slot:prepend>
                  <v-icon :color="getFileIconColor(doc.name || doc.filename || doc.originalName)">{{
                    getFileIcon(doc.name || doc.filename || doc.originalName) }}</v-icon>
                </template>
                <v-list-item-title class="document-name">
                  {{ doc.name || doc.filename || doc.originalName || `Document ${docIndex + 1}` }}
                </v-list-item-title>
                <template v-slot:append>
                  <div class="d-flex align-center">
                    <v-btn icon size="small" @click="handleDocumentView(doc)" class="action-button mr-2"
                      title="View Document" :disabled="!doc.url && !doc.path">
                      <v-icon color="primary">mdi-eye</v-icon>
                    </v-btn>
                    <v-btn v-if="doc.url || doc.path" icon size="small" @click="downloadDocument(doc)"
                      class="action-button" title="Download Document" :disabled="!doc.url && !doc.path">
                      <v-icon color="success">mdi-download</v-icon>
                    </v-btn>
                  </div>
                </template>
              </v-list-item>
            </v-list>
          </div>
          <span v-else class="no-data-message">
            <v-icon left>mdi-information-outline</v-icon>
            No documents available
          </span>
        </v-col>
      </v-row>
    </v-card>

    <v-dialog v-model="imageViewDialog" max-width="800">
      <v-card>
        <v-card-title class="headline dialog-title">Image Preview</v-card-title>
        <v-card-text>
          <v-img :src="currentDocumentUrl" contain max-height="600"></v-img>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="primary" text @click="imageViewDialog = false">Close</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="pdfViewDialog" max-width="900" fullscreen content-class="pdf-dialog-fullscreen">
      <v-card>
        <v-card-title class="headline d-flex justify-space-between align-center dialog-title">
          PDF Preview
          <v-btn icon @click="pdfViewDialog = false" aria-label="Close PDF viewer">
            <v-icon>mdi-close</v-icon>
          </v-btn>
        </v-card-title>
        <v-card-text class="pdf-viewer-container">
          <iframe :src="currentDocumentUrl" width="100%" height="100%" frameborder="0"></iframe>
        </v-card-text>
      </v-card>
    </v-dialog>

    <v-card class="detail-card mt-6 rounded-lg pa-6" elevation="8">
      <v-card-title class="card-title">
        <v-icon left color="#4d90fe">mdi-timeline-text-outline</v-icon>
        Activity Log
      </v-card-title>
      <v-divider class="card-divider"></v-divider>
      <v-row class="align-center mb-4">
        <v-col cols="12" sm="8" md="6">
          <v-text-field v-model="activitySearch" append-inner-icon="mdi-magnify" label="Search Activity" single-line
            hide-details outlined dense clearable class="activity-search-field"></v-text-field>
        </v-col>
      </v-row>
      <v-row>
        <v-col cols="12">
          <div v-if="paginatedActivity && paginatedActivity.length > 0">
            <v-timeline dense clipped class="activity-timeline">
              <v-timeline-item v-for="(activity, index) in paginatedActivity" :key="activity.id || index" size="small"
                :color="getActivityColor(activity.action)" class="activity-timeline-item" icon="mdi-circle-small"
                fill-dot>
                <template v-slot:opposite>
                  <span class="text-caption activity-date clickable-date"
                    @click="toggleActivityDetails(activity.id || index)">
                    {{ new Date(activity.actionDate).toLocaleString() }}
                    <v-icon small class="ml-1">
                      {{ expandedActivities.includes(activity.id || index) ? 'mdi-chevron-up' : 'mdi-chevron-down' }}
                    </v-icon>
                  </span>
                </template>
                <div class="activity-content">
                  <div class="font-weight-bold activity-action-by">
                    <v-icon small left :color="getActivityColor(activity.action)">{{ getActivityIcon(activity.action)
                    }}</v-icon>
                    {{ getUserName(activity.actionBy) }}
                    <span class="text-caption grey--text ml-2">({{ activity.action }})</span>
                  </div>
                  <v-expand-transition>
                    <div v-if="expandedActivities.includes(activity.id || index)" class="activity-details mt-2">
                      <p class="mb-0 text-caption activity-changes-label">Changes:</p>
                      <ul class="activity-details-list">
                        <li v-for="(detail, key) in filteredActivityDetails(activity)" :key="key" class="activity-detail-item">
                          <strong>{{ formatDetailKey(key) }}:</strong>
                          <span v-if="detail && typeof detail === 'object' && 'old' in detail && 'new' in detail"
                            class="change-tracking">
                            <span class="old-value">"{{ formatDetailValue(detail.old, key) }}"</span>
                            <v-icon small class="mx-1 change-arrow">mdi-arrow-right</v-icon>
                            <span class="new-value">"{{ formatDetailValue(detail.new, key) }}"</span>
                          </span>
                          <span v-else class="single-value">
                            {{ formatDetailValue(detail, key) }}
                          </span>
                        </li>
                      </ul>
                    </div>
                  </v-expand-transition>
                  <div
                    v-if="expandedActivities.includes(activity.id || index) && (!filteredActivityDetails(activity) || Object.keys(filteredActivityDetails(activity)).length === 0)"
                    class="text-caption no-activity-details mt-2">
                    <v-icon small left>mdi-information-outline</v-icon>
                    No specific details available.
                  </div>
                </div>
              </v-timeline-item>
            </v-timeline>
            <div class="d-flex justify-center mt-4" v-if="totalActivityPages > 1">
              <v-pagination v-model="activityCurrentPage" :length="totalActivityPages" :total-visible="7"
                color="primary" rounded="circle"></v-pagination>
            </div>
          </div>
          <span v-else class="no-data-message">
            <v-icon left>mdi-information-outline</v-icon>
            No activity log available for the current search/filters.
          </span>
        </v-col>
      </v-row>
    </v-card>

    <v-card class="detail-card mt-6 rounded-lg pa-6" elevation="8">
      <v-card-title class="card-title">
        <v-icon left color="#4d90fe">mdi-message-text-outline</v-icon>
        Messages & Chat
      </v-card-title>
      <v-divider class="card-divider"></v-divider>
      <v-row>
        <v-col cols="12" md="6">
          <h3 class="section-subtitle">
            <v-icon left color="#78909C">mdi-email-multiple-outline</v-icon>
            Message Threads
          </h3>
          <div v-if="isLoadingMessages" class="loading-message">
            <v-progress-circular indeterminate color="primary" size="24"></v-progress-circular>
            Loading messages...
          </div>
          <div v-else-if="messageError" class="error-message">
            <v-icon left color="error">mdi-alert-circle-outline</v-icon>
            Error: {{ messageError }}
          </div>
          <div v-else-if="messages && messages.length > 0">
            <v-list dense class="message-threads-list">
              <v-list-item v-for="message in messages" :key="message.id" @click="fetchChatMessages(message.id)"
                :class="{ 'selected-message-thread': selectedMessageId === message.id }" class="message-thread-item">
                <v-list-item-content>
                  <v-list-item-title class="font-weight-medium message-subject">
                    <v-icon small left color="#42A5F5">mdi-message-outline</v-icon>
                    {{ message.subject }}
                    <v-chip v-if="message.unreadCount > 0" color="red" size="small" class="unread-chip">
                      {{ message.unreadCount }} New
                    </v-chip>
                  </v-list-item-title>
                  <v-list-item-subtitle class="message-preview">{{ message.message }}</v-list-item-subtitle>
                  <v-list-item-subtitle class="text-caption message-date">
                  </v-list-item-subtitle>
                </v-list-item-content>
              </v-list-item>
            </v-list>
          </div>
          <div v-else class="no-data-message">
            <v-icon left>mdi-information-outline</v-icon>
            No message threads available for this service request.
          </div>
        </v-col>

        <v-col cols="12" md="6">
          <h3 class="section-subtitle">
            <v-icon left color="#78909C">mdi-chat-processing-outline</v-icon>
            Chat History
          </h3>
          <div v-if="isLoadingChats" class="loading-message">
            <v-progress-circular indeterminate color="primary" size="24"></v-progress-circular>
            Loading chat...
          </div>
          <div v-else-if="chatError" class="error-message">
            <v-icon left color="error">mdi-alert-circle-outline</v-icon>
            Error: {{ chatError }}
          </div>
          <div v-else-if="selectedMessageId && chatMessagesWithSenderInfo.length > 0">
            <v-list dense class="chat-history-list">
              <v-list-item v-for="chat in chatMessagesWithSenderInfo" :key="chat.id"
                :class="{ 'my-message': chat.isCurrentUser, 'other-message': !chat.isCurrentUser }"
                class="chat-bubble-item">
                <v-list-item-content :class="chat.isCurrentUser ? 'my-message-content' : 'other-message-content'">
                  <v-list-item-title class="font-weight-bold chat-sender">
                    <v-icon small left
                      :color="chat.isCurrentUser ? 'white' : '#607D8B'">mdi-account-circle-outline</v-icon>
                    {{ chat.sender?.username || 'Unknown User' }}
                  </v-list-item-title>
                  <v-list-item-subtitle class="chat-message-text">
                    {{ chat.message }}
                  </v-list-item-subtitle>
                  <v-list-item-subtitle class="text-caption chat-timestamp">
                    <v-icon x-small left :color="chat.isCurrentUser ? 'white' : '#999'">mdi-clock-outline</v-icon>
                    {{ new Date(chat.createdAt).toLocaleString() }}
                  </v-list-item-subtitle>
                </v-list-item-content>
              </v-list-item>
            </v-list>
            <v-card-actions class="chat-input-area">
              <v-text-field v-model="newChatMessage" label="Type your message" outlined dense hide-details
                @keyup.enter="sendChatMessage" class="chat-text-field"></v-text-field>
              <v-btn icon color="primary" @click="sendChatMessage" :disabled="!newChatMessage.trim()"
                class="send-button">
                <v-icon>mdi-send</v-icon>
              </v-btn>
            </v-card-actions>
          </div>
          <div v-else-if="selectedMessageId" class="no-data-message">
            <v-icon left>mdi-information-outline</v-icon>
            No chat messages for this thread yet. Start a conversation!
            <v-card-actions class="chat-input-area mt-3">
              <v-text-field v-model="newChatMessage" label="Type your message" outlined dense hide-details
                @keyup.enter="sendChatMessage" class="chat-text-field"></v-text-field>
              <v-btn icon color="primary" @click="sendChatMessage" :disabled="!newChatMessage.trim()"
                class="send-button">
                <v-icon>mdi-send</v-icon>
              </v-btn>
            </v-card-actions>
          </div>
          <div v-else class="no-data-message">
            <v-icon left>mdi-message-arrow-right-outline</v-icon>
            Select a message thread to view chat history.
          </div>
        </v-col>
      </v-row>
    </v-card>
  </v-container>
</template>

<script>
import { mapActions, mapState, mapGetters } from 'vuex';

export default {
  name: 'ServiceInner',
  data() {
    return {
      selectedMessageId: null,
      newChatMessage: '',
      currentUser: null,
      users: [],
      expandedActivities: [],
      activitySearch: '',
      activityCurrentPage: 1,
      activityItemsPerPage: 5,
      imageViewDialog: false,
      pdfViewDialog: false,
      currentDocumentUrl: '',
      isLoadingService: false,
      isSendingMessage: false,
    };
  },

  computed: {
    ...mapState('service', ['editServicetValue']),
    ...mapState('message', {
      rawMessages: 'MessageList',
      chatMessages: 'ChatList',
      isLoadingMessages: 'loading',
      isLoadingChats: 'loading',
      messageError: 'error',
      chatError: 'error',
    }),
    ...mapGetters('message', ['getAllMessages', 'getChatMessages']),
    ...mapGetters('user', {
      allUsers: 'getAllUsers'
    }),

    breadcrumbs() {
      return [
        { text: 'Home', disabled: false, href: '/' },
        { text: 'Service Requests', disabled: false, href: '/service-requests' },
        {
          text: this.editServicetValue?.sale?.serialNo || 'Service Request',
          disabled: true,
          href: '#'
        },
      ];
    },

    processedDocuments() {
      const rawDocuments = this.editServicetValue?.documents;
      if (!rawDocuments?.length) return [];

      let documents = [];
      if (typeof rawDocuments === 'string') {
        try {
          documents = JSON.parse(rawDocuments);
        } catch {
          documents = [rawDocuments];
        }
      } else {
        documents = Array.isArray(rawDocuments) ? rawDocuments : [rawDocuments];
      }

      return documents
        .map((doc, index) => this.normalizeDocumentObject(doc, index))
        .filter(doc => doc.url || doc.path);
    },

    filteredActivity() {
      const allActivity = this.editServicetValue?.all_activity;
      if (!Array.isArray(allActivity)) return [];

      let filtered = [...allActivity];
      if (this.activitySearch) {
        const searchTerm = this.activitySearch.toLowerCase();
        filtered = filtered.filter(activity =>
          this.activityMatchesSearch(activity, searchTerm)
        );
      }
      return filtered.sort((a, b) => new Date(b.actionDate) - new Date(a.actionDate));
    },

    paginatedActivity() {
      const start = (this.activityCurrentPage - 1) * this.activityItemsPerPage;
      return this.filteredActivity.slice(start, start + this.activityItemsPerPage);
    },

    totalActivityPages() {
      return Math.ceil(this.filteredActivity.length / this.activityItemsPerPage);
    },

    messages() {
      const currentServiceId = this.editServicetValue?.id;
      if (!currentServiceId || !this.rawMessages?.length) {
        return [];
      }
      return this.rawMessages.filter(message => message.serviceRequestId === currentServiceId);
    },

    chatMessagesWithSenderInfo() {
      if (!this.chatMessages?.length || !this.currentUser) {
        return [];
      }

      const processedChats = this.chatMessages.map(chat => ({
        ...chat,
        isCurrentUser: chat.senderId === this.currentUser.id,
        sender: this.findUserById(chat.senderId),
      }));
      return processedChats;
    },

    filteredActivityDetails() {
      return (activity) => {
        if (!activity.details || typeof activity.details !== 'object') return {};
        return Object.fromEntries(
          Object.entries(activity.details).filter(
            ([key]) => !['attendedOn', 'completedOn', 'type'].includes(key)
          )
        );
      };
    },
  },

  watch: {
    editServicetValue: {
      handler(newValue) {
        if (newValue?.id && this.shouldFetchMessages(newValue.id)) {
          this.fetchMessagesForServiceRequest(newValue.id);
        }
      },
      deep: true,
      immediate: true,
    },

    activitySearch() {
      this.activityCurrentPage = 1;
    },

    allUsers: {
      handler(newUsers) {
        if (newUsers?.length > 0) {
          this.$nextTick(() => {
            this.updateCombinedUsers();
          });
        }
      },
      deep: true,
      immediate: true,
    },
  },

  methods: {
    ...mapActions('service', ['GET_SERVICE_WITH_ID']),
    ...mapActions('message', [
      'GET_MESSAGE_LIST',
      'GET_CHAT_MESSAGES',
      'ADD_CHAT',
      'MARK_CHATS_AS_READ'
    ]),
    ...mapActions('user', ['GET_USER_LIST']),

    async getServiceDetails() {
      try {
        this.isLoadingService = true;
        const serviceId = String(this.$route.params.id);
        await this.GET_SERVICE_WITH_ID(serviceId);
      } catch (error) {
        this.$toast?.error('Failed to load service details');
      } finally {
        this.isLoadingService = false;
      }
    },

    shouldFetchMessages(serviceId) {
      return true;
    },

    async fetchMessagesForServiceRequest(serviceRequestId) {
      try {
        await this.GET_MESSAGE_LIST({ serviceRequestId });
      } catch (error) {
        this.$toast?.error('Failed to load messages');
      }
    },

    async fetchChatMessages(messageId) {
      this.selectedMessageId = messageId;
      try {
        await this.GET_CHAT_MESSAGES({ messageId });
        await this.markUnreadChatsAsRead();
      } catch (error) {
        this.$toast?.error('Failed to load chat messages');
      }
    },

    async markUnreadChatsAsRead() {
      const unreadChatIds = this.chatMessages
        .filter(chat => !chat.readStatus && chat.senderId !== this.currentUser?.id)
        .map(chat => chat.id);

      if (unreadChatIds.length > 0) {
        await this.MARK_CHATS_AS_READ(unreadChatIds);
        await this.fetchMessagesForServiceRequest(this.editServicetValue.id);
      }
    },

    async sendChatMessage() {
      if (!this.canSendMessage()) return;

      try {
        this.isSendingMessage = true;
        const payload = {
          message: this.newChatMessage.trim(),
          messageId: this.selectedMessageId,
          senderId: this.currentUser.id,
        };

        await this.ADD_CHAT(payload);
        this.newChatMessage = '';

        await this.GET_CHAT_MESSAGES({ messageId: this.selectedMessageId });
        await this.fetchMessagesForServiceRequest(this.editServicetValue.id);

        this.$toast?.success('Message sent successfully');
      } catch (error) {
        this.$toast?.error('Failed to send message');
      } finally {
        this.isSendingMessage = false;
      }
    },

    canSendMessage() {
      return this.newChatMessage.trim() &&
        this.selectedMessageId &&
        this.currentUser &&
        !this.isSendingMessage;
    },

    loadCurrentUser() {
      try {
        const userStr = localStorage.getItem('user');
        this.currentUser = userStr ? JSON.parse(userStr) : null;
      } catch (error) {
        this.currentUser = null;
        console.error("Error parsing user from localStorage:", error);
      }
    },

    updateCombinedUsers() {
      if (!this.allUsers?.length) {
        this.users = [];
        return;
      }

      const userMap = new Map();
      this.allUsers.forEach(user => {
        if (user?.id && user?.username && !userMap.has(user.id)) {
          userMap.set(user.id, user);
        }
      });
      this.users = Array.from(userMap.values());
    },

    findUserById(userId) {
      return this.users.find(user => user.id === userId);
    },

    getUserName(userId) {
      if (userId == null) return 'N/A';
      const user = this.findUserById(userId);
      return user?.username || `User ${userId} (Unknown)`;
    },

    normalizeDocumentObject(doc, index) {
      if (typeof doc === 'string') {
        const filename = doc.split('/').pop() || `Document ${index + 1}`;
        return {
          name: filename,
          filename,
          url: doc,
          path: doc,
          originalName: filename,
        };
      }

      if (doc && typeof doc === 'object') {
        return {
          name: doc.name || doc.filename || doc.originalName || `Document ${index + 1}`,
          filename: doc.filename || doc.name || `Document ${index + 1}`,
          url: doc.url || doc.path,
          path: doc.path || doc.url,
          originalName: doc.originalName || doc.name || doc.filename || `Document ${index + 1}`,
        };
      }
      return {};
    },

    getFileIcon(filename) {
      if (!filename) return 'mdi-file';
      const ext = filename.toLowerCase().split('.').pop();
      const iconMap = {
        pdf: 'mdi-file-pdf-box',
        doc: 'mdi-file-word-box',
        docx: 'mdi-file-word-box',
        txt: 'mdi-file-document',
        jpg: 'mdi-file-image',
        jpeg: 'mdi-file-image',
        png: 'mdi-file-image',
        gif: 'mdi-file-image',
        bmp: 'mdi-file-image',
        zip: 'mdi-file-zip',
        rar: 'mdi-file-zip',
        xls: 'mdi-file-excel',
        xlsx: 'mdi-file-excel',
      };
      return iconMap[ext] || 'mdi-file';
    },

    getFileIconColor(filename) {
      if (!filename) return 'grey';
      const ext = filename.toLowerCase().split('.').pop();
      const colorMap = {
        pdf: 'red darken-2',
        doc: 'blue darken-1',
        docx: 'blue darken-1',
        txt: 'grey darken-1',
        jpg: 'purple darken-1',
        jpeg: 'purple darken-1',
        png: 'purple darken-1',
        gif: 'purple darken-1',
        bmp: 'purple darken-1',
        zip: 'orange darken-2',
        rar: 'orange darken-2',
        xls: 'green darken-2',
        xlsx: 'green darken-2',
      };
      return colorMap[ext] || 'grey';
    },

    handleDocumentView(doc) {
      const url = doc.url || doc.path;
      if (!url) return;
      const fullUrl = this.buildFullDocumentUrl(url);
      const ext = (doc.name || doc.filename || '').toLowerCase().split('.').pop();
      this.currentDocumentUrl = fullUrl;
      if (['jpg', 'jpeg', 'png', 'gif', 'bmp'].includes(ext)) {
        this.imageViewDialog = true;
      } else if (ext === 'pdf') {
        this.pdfViewDialog = true;
      } else {
        window.open(fullUrl, '_blank');
      }
    },

    downloadDocument(doc) {
      const url = doc.url || doc.path;
      if (!url) return;
      try {
        const link = document.createElement('a');
        link.href = this.buildFullDocumentUrl(url);
        link.download = doc.name || doc.filename || doc.originalName || 'document';
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (error) {
        this.$toast?.error('Failed to download document');
      }
    },

    buildFullDocumentUrl(url) {
      if (url.startsWith('http')) return url;
      const baseUrl = process.env.VUE_APP_API_BASE_URL || 'http://localhost:3025';
      const separator = url.startsWith('/') ? '' : '/';
      return `${baseUrl}${separator}${url}`;
    },

    activityMatchesSearch(activity, searchTerm) {
      const actionMatch = activity.action?.toLowerCase().includes(searchTerm);
      const userMatch = this.getUserName(activity.actionBy).toLowerCase().includes(searchTerm);
      const detailsMatch = this.filteredActivityDetails(activity) ?
        JSON.stringify(this.filteredActivityDetails(activity)).toLowerCase().includes(searchTerm) : false;
      return actionMatch || userMatch || detailsMatch;
    },

    getActivityColor(action) {
      const colorMap = {
        CREATE: 'green',
        UPDATE: 'blue',
        DELETE: 'red',
      };
      return colorMap[action] || 'grey';
    },

    getActivityIcon(action) {
      const iconMap = {
        CREATE: 'mdi-plus-circle-outline',
        UPDATE: 'mdi-pencil-circle-outline',
        DELETE: 'mdi-delete-circle-outline',
      };
      return iconMap[action] || 'mdi-information-outline';
    },

    toggleActivityDetails(activityIdOrIndex) {
      const index = this.expandedActivities.indexOf(activityIdOrIndex);
      if (index > -1) {
        this.expandedActivities.splice(index, 1);
      } else {
        this.expandedActivities.push(activityIdOrIndex);
      }
    },

    getStatusColor(status) {
      const statusColors = {
        'Open': '#1985d0',
        'In Progress': '#20ad8c',
        'Completed': '#fd5e00',
        'Canceled': '#dc3545',
        'Verified': '#1ad539'
      };
      return statusColors[status] || 'grey';
    },

    formatDetailKey(key) {
      const customKeys = {
        callHandleId: 'Call Handle',
        priorityId: 'Priority',
        serviceTypeId: 'Name',
        workingStatusId: 'Working Status',
        workingConditionId: 'Working Condition',
        saleId: 'Name',
        userId: 'User',
        description: 'Problem Description',
        solutionProvided: 'Solution Provided',
        isApprovedByCEO: 'Approved by CEO',
        serialNo: 'Serial Number',
        equipmentName: 'Machine Name',
        clientName: 'Client Name',
        city: 'City',
        callRegisterDate: 'Call Register Date',
        service_by: 'Service By',
        requestTypeId: 'Request Type',
        createdAt: 'Created At',
        updatedAt: 'Updated At',
        documents: 'Documents',
        id: 'Name',
      };
      return customKeys[key] || (key.endsWith('Id') ? 'Name' : key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()));
    },

    formatDetailValue(value, key) {
      if (['attendedOn', 'completedOn', 'type'].includes(key)) {
        return null;
      }
      if (value === null || value === undefined) {
        return 'N/A';
      }
      const userRelatedKeys = ['userId', 'actionBy', 'senderId', 'assignedToId'];
      if (userRelatedKeys.includes(key)) {
        if (typeof value === 'object' && value !== null) {
          return value.username || this.getUserName(value.id) || 'Unknown User';
        }
        return this.getUserName(value);
      }
      if (key === 'service_by') {
        if (typeof value === 'object' && value !== null) {
          return value.username || value.name || 'Unknown';
        }
        return value || 'N/A';
      }
      if (key.endsWith('Id') && typeof value === 'number') {
        const displayValue = this.getDisplayValueForId(key, value);
        if (displayValue) {
          return displayValue;
        }
      }
      if (typeof value === 'boolean') {
        return value ? 'Yes' : 'No';
      }
      if (typeof value === 'string' && value.match(/^\d{4}-\d{2}-\d{2}T/)) {
        return new Date(value).toLocaleDateString();
      }
      if (typeof value === 'string' && value.match(/^\d{4}-\d{2}-\d{2}$/)) {
        const date = new Date(value);
        if (!isNaN(date.getTime())) {
          return date.toLocaleDateString();
        }
      }
      if (Array.isArray(value)) {
        if (key === 'documents') {
          const docNames = value.map(url => {
            try {
              const parsed = typeof url === 'string' ? url : (url.path || url.url);
              return parsed ? parsed.split('/').pop() : '';
            } catch (e) {
              return '';
            }
          }).filter(Boolean);
          return docNames.length > 0 ? docNames.join(', ') : 'None';
        }
        return value.map(item => this.extractValueFromObject(item) || item).join(', ');
      }
      if (typeof value === 'object' && value !== null) {
        if (value.hasOwnProperty('old') && value.hasOwnProperty('new')) {
          const oldValue = this.formatDetailValue(value.old, key);
          const newValue = this.formatDetailValue(value.new, key);
          if ((oldValue === 'N/A' || oldValue === null) && newValue !== 'N/A' && newValue !== null) {
            return `"${newValue}"`;
          }
          return oldValue === newValue ? `"${newValue}"` : `"${oldValue}" → "${newValue}"`;
        }
        if (this.isLookupObject(value)) {
          return this.extractDisplayValue(value);
        }
        if (key === 'createdData' || !key.endsWith('Id')) {
          try {
            let parsedData = value;
            if (typeof value === 'string') {
              parsedData = JSON.parse(value);
            }
            if (typeof parsedData === 'object' && parsedData !== null) {
              const formattedEntries = Object.entries(parsedData)
                .map(([k, v]) => {
                  const formattedValue = this.formatDetailValue(v, k);
                  if (formattedValue === null) {
                    return null;
                  }
                  const formattedKey = this.formatDetailKey(k);
                  if (k.endsWith('Id') && typeof v === 'number' && formattedValue === 'N/A') {
                    return null;
                  }
                  return `${formattedKey}: "${formattedValue}"`;
                })
                .filter(entry => entry !== null)
                .join('; ');
              return formattedEntries || 'No details';
            }
          } catch (e) {
            return JSON.stringify(value);
          }
        }
        return this.extractValueFromObject(value);
      }
      if (typeof value === 'string') {
        return value.replace(/^"(.*)"$/, '$1');
      }
      return value;
    },

    isLookupObject(obj) {
      const lookupPatterns = [
        'name', 'username', 'priority', 'callHandle', 'workingStatus',
        'workingCondition', 'type', 'equipmentName', 'city'
      ];
      return obj.id !== undefined && lookupPatterns.some(prop => obj[prop] !== undefined);
    },

    extractDisplayValue(obj) {
      const displayProps = [
        'username', 'name', 'priority', 'callHandle', 'workingStatus',
        'workingCondition', 'type', 'equipmentName', 'city', 'serialNo'
      ];
      for (const prop of displayProps) {
        if (obj[prop] !== undefined && obj[prop] !== null) {
          return obj[prop];
        }
      }
      return obj.id;
    },

    getDisplayValueForId(idKey, idValue) {
      if (!this.editServicetValue || idValue === null || idValue === undefined) return null;
      const lookupMap = {
        'priorityId': () => this.editServicetValue.priority?.priority,
        'callHandleId': () => this.editServicetValue.call_handle?.callHandle,
        'workingStatusId': () => this.editServicetValue.working_status?.workingStatus,
        'workingConditionId': () => this.editServicetValue.working_condition?.workingCondition,
        'serviceTypeId': () => this.editServicetValue.service_type?.type,
        'requestTypeId': () => this.editServicetValue.request_type?.type,
        'saleId': () => this.editServicetValue.sale?.serialNo,
        'userId': () => this.getUserName(idValue),
      };
      const lookup = lookupMap[idKey];
      return lookup ? lookup() : null;
    },

    extractValueFromObject(obj) {
      if (this.isLookupObject(obj)) {
        return this.extractDisplayValue(obj);
      }
      const specificKeys = [
        'username', 'name', 'filename', 'originalName',
        'priority', 'callHandle', 'workingCondition', 'workingStatus', 'type',
        'serialNo', 'equipmentName', 'city', 'description', 'solutionProvided',
      ];
      for (const key of specificKeys) {
        if (obj[key] !== undefined && obj[key] !== null) {
          return obj[key];
        }
      }
      if ('old' in obj && 'new' in obj) {
        const oldValue = this.extractValueFromObject(obj.old);
        const newValue = this.extractValueFromObject(obj.new);
        return `"${oldValue}" → "${newValue}"`;
      }
      if (obj.id && obj.name) return obj.name;
      if (obj.id && obj.value) return obj.value;
      if (Object.keys(obj).length === 1 && obj[Object.keys(obj)[0]]) {
        return obj[Object.keys(obj)[0]];
      }
      try {
        const simpleObj = {};
        for (const k in obj) {
          if (typeof obj[k] !== 'object' && !Array.isArray(obj[k])) {
            simpleObj[this.formatDetailKey(k)] = obj[k];
          }
        }
        return Object.keys(simpleObj).length > 0
          ? JSON.stringify(simpleObj).replace(/[{}"']/g, '')
          : JSON.stringify(obj);
      } catch (e) {
        return String(obj);
      }
    },
  },

  async mounted() {
    this.loadCurrentUser();
    try {
      await this.GET_USER_LIST();
      await this.getServiceDetails();
    } catch (error) {
    }
  },
};
</script>




<style scoped>
/* Main container styles */
.main-container {
  padding: 24px;
  background-color: #f5f7fa;
  min-height: calc(100vh - 64px);
  /* Adjust based on your app bar height */
}

/* Breadcrumbs */
.breadcrumbs-container {
  padding: 0 16px;
  background-color: #4d90fe;
  color: white;
  border-radius: 8px;
  margin-bottom: 24px;
}

.custom-breadcrumb-item {
  color: white !important;
  font-size: 1rem;
}

.custom-breadcrumb-item.v-breadcrumbs-item--disabled {
  color: rgba(255, 255, 255, 0.7) !important;
}

/* Card styles */
.detail-card {
  background-color: #ffffff;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08) !important;
}

.card-title {
  font-size: 1.6rem;
  font-weight: 600;
  color: #333;
  padding-bottom: 8px;
}

.card-divider {
  margin-bottom: 16px;
  border-color: #eee !important;
}

.detail-row {
  margin-top: 16px;
}

.detail-column {
  padding: 8px 16px;
}

.detail-item {
  font-size: 0.95rem;
  margin-bottom: 8px;
  color: #555;
}

.detail-item strong {
  color: #333;
  min-width: 120px;
  display: inline-block;
}

.detail-value {
  color: #777;
}

.status-chip {
  font-weight: bold;
  height: 24px;
}

.no-data-message {
  display: flex;
  align-items: center;
  justify-content: center;
  color: #777;
  padding: 20px;
  background-color: #f0f0f0;
  border-radius: 8px;
  margin-top: 16px;
  font-style: italic;
}

.no-data-message .v-icon {
  margin-right: 8px;
}

/* Document Section */
.document-list {
  background-color: transparent !important;
  padding: 0;
}

.document-list-item {
  border-bottom: 1px solid #eee;
  margin-bottom: 8px;
  padding: 10px 0;
}

.document-list-item:last-child {
  border-bottom: none;
}

.document-name {
  font-weight: 500;
  color: #444;
}

.action-button {
  margin-left: 8px;
  transition: transform 0.2s ease-in-out;
}

.action-button:hover {
  transform: translateY(-2px);
}

/* Dialogs */
.dialog-title {
  color: #333;
  font-weight: 600;
  border-bottom: 1px solid #eee;
  padding: 16px 24px;
}

.pdf-dialog-fullscreen .v-card {
  height: 100vh;
  display: flex;
  flex-direction: column;
}

.pdf-viewer-container {
  flex-grow: 1;
  padding: 0 !important;
}

/* Activity Log Section */
.activity-search-field {
  max-width: 400px;
}

.activity-timeline {
  margin-top: 20px;
  padding-left: 10px;
}

.activity-timeline-item {
  margin-bottom: 20px;
  padding-bottom: 10px;
}

.activity-timeline-item:last-child {
  margin-bottom: 0;
  padding-bottom: 0;
}

.activity-date {
  color: #777;
  font-size: 0.85rem;
}

.clickable-date {
  cursor: pointer;
}

.activity-content {
  background-color: #f9f9f9;
  border-radius: 8px;
  padding: 12px 16px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
}

.activity-timeline-item:hover .activity-content {
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.activity-action-by {
  font-size: 0.95rem;
  color: #2c3e50;
  display: flex;
  align-items: center;
  margin-bottom: 5px;
}

.activity-action-by .v-icon {
  margin-right: 6px;
}

.activity-changes-label {
  font-weight: 600;
  color: #555;
  margin-top: 8px;
}

.activity-details-list {
  list-style-type: none;
  padding-left: 0;
  margin-top: 5px;
}

.activity-detail-item {
  font-size: 0.875rem;
  color: #666;
  line-height: 1.5;
  padding: 2px 0;
}

.change-tracking .old-value {
  color: #e74c3c;
  /* Red for old value */
  text-decoration: line-through;
  /* Strikethrough for old value */
}

.change-tracking .new-value {
  color: #28a745;
  /* Green for new value */
  font-weight: bold;
}

.change-tracking .change-arrow {
  color: #555;
  margin: 0 4px;
}

.no-activity-details {
  color: #888;
  font-style: italic;
  display: flex;
  align-items: center;
}

/* Message & Chat Section */
.section-subtitle {
  font-size: 1.2rem;
  font-weight: 500;
  color: #3f51b5;
  margin-bottom: 15px;
  display: flex;
  align-items: center;
}

.section-subtitle .v-icon {
  margin-right: 8px;
}

.loading-message,
.error-message {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  border-radius: 8px;
  margin-top: 10px;
  font-style: italic;
}

.loading-message {
  background-color: #e3f2fd;
  color: #2196f3;
}

.error-message {
  background-color: #ffebee;
  color: #f44336;
}

.loading-message .v-icon,
.error-message .v-icon {
  margin-right: 8px;
}


.message-threads-list {
  max-height: 400px;
  overflow-y: auto;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background-color: #fcfcfc;
  padding: 0;
}

.message-thread-item {
  border-bottom: 1px solid #f0f0f0;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

.message-thread-item:hover {
  background-color: #e8eaf6;
}

.selected-message-thread {
  background-color: #c5cae9 !important;
  border-left: 4px solid #3f51b5;
}

.message-subject {
  color: #3f51b5;
}

.message-preview {
  color: #666;
  font-size: 0.85rem;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.message-date {
  color: #999;
  font-size: 0.75rem;
  text-align: right;
  margin-top: 4px;
}

.unread-chip {
  margin-left: 8px;
  font-weight: bold;
}

.chat-history-list {
  max-height: 400px;
  overflow-y: auto;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background-color: #fcfcfc;
  padding: 10px;
  display: flex;
  flex-direction: column;
}

.chat-bubble-item {
  margin-bottom: 10px;
  padding: 0 !important;
  display: flex;
}

.chat-bubble-item .v-list-item__content {
  padding: 8px 12px;
  border-radius: 18px;
  max-width: 85%;
  word-wrap: break-word;
  white-space: normal;
}

.my-message {
  justify-content: flex-end;
}

.my-message-content {
  background-color: #4d90fe;
  color: white;
  margin-left: auto;
  /* Pushes to the right */
}

.other-message-content {
  background-color: #e0e0e0;
  color: #333;
  margin-right: auto;
  /* Pushes to the left */
}

.chat-sender {
  font-size: 0.8rem;
  margin-bottom: 4px;
  display: flex;
  align-items: center;
}

.my-message-content .chat-sender {
  color: rgba(255, 255, 255, 0.8);
}

.chat-message-text {
  font-size: 0.9rem;
  line-height: 1.4;
  color: inherit;
  /* Inherit color from parent bubble */
}

.chat-timestamp {
  font-size: 0.7rem;
  margin-top: 5px;
  text-align: right;
  opacity: 0.8;
}

.my-message-content .chat-timestamp {
  color: rgba(255, 255, 255, 0.7);
}


.chat-input-area {
  padding-top: 10px;
  border-top: 1px solid #eee;
  margin-top: 10px;
  display: flex;
  align-items: center;
  gap: 10px;
}

.chat-text-field {
  flex-grow: 1;
}

.send-button {
  min-width: 40px !important;
  width: 40px !important;
  height: 40px !important;
}
</style>


<style scoped>
/* Main Container */
.main-container {
  background: linear-gradient(to right bottom, #eef7ff, #f7fdff);
  /* Lighter, softer gradient */
  min-height: 100vh;
  padding: 30px;
  font-family: 'Inter', sans-serif;
  /* A more modern, clean font */
  color: #333;
  /* Default text color */
}

/* Header Section for Breadcrumbs and Back Button */
.header-section {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 25px;
  padding: 10px 0;
  border-bottom: 1px solid #e0e0e0;
}

.breadcrumbs-container {
  background-color: #3f51b5;
  /* Primary color */
  color: white;
  padding: 8px 16px;
  border-radius: 4px;
}

.custom-breadcrumb-item {
  color: white !important;
  /* Important to override default Vuetify text color */
}

.custom-breadcrumb-item.v-breadcrumbs-item--disabled {
  opacity: 0.8;
}

.back-button {
  background-color: #607D8B;
  /* Darker grey for a subtle back button */
  color: white;
  margin-left: 20px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.back-button:hover {
  background-color: #546E7A;
  /* Slightly darker on hover */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

/* Card Base Styles */
.detail-card {
  background-color: #ffffff;
  border-radius: 12px;
  padding: 25px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
  /* Softer shadow */
  transition: all 0.3s ease;
  margin-bottom: 25px;
  border: 1px solid rgba(0, 0, 0, 0.03);
  /* Very subtle border */
}

/* Original Card Title (Service Request Details) */
.detail-card .card-title {
  font-size: 1.5rem;
  font-weight: 600;
  color: #2c3e50;
  margin-bottom: 15px;
  padding-bottom: 10px;
  border-bottom: 2px solid #f0f0f0;
  display: flex;
  align-items: center;
}

.detail-card .card-title::before {
  content: '';
  display: inline-block;
  width: 8px;
  height: 24px;
  background-color: #4d90fe;
  margin-right: 12px;
  border-radius: 4px;
}


.card-divider {
  margin: 15px 0;
  border-color: rgba(0, 0, 0, 0.08);
}

/* Original Detail Rows and Columns (Service Request Details) */
.detail-row {
  margin: 0 -10px;
}

.detail-column {
  padding: 0 15px;
}

.detail-item {
  margin-bottom: 15px;
  line-height: 1.5;
  font-size: 0.95rem;
  color: #444;
  display: flex;
  flex-wrap: wrap;
}

.detail-item strong {
  color: #333;
  font-weight: 600;
  margin-right: 5px;
  min-width: 140px;
}

.detail-value {
  color: #555;
  font-weight: 500;
  flex: 1;
}

/* Status Chip - Kept the updated style as it's general */
.status-chip {
  height: 28px;
  /* Slightly taller */
  font-size: 0.85rem;
  font-weight: 600;
  border-radius: 14px;
  /* More rounded */
  padding: 0 14px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  /* Subtle shadow on chip */
}

/* --- Documents Section (New Styles) --- */
.detail-card:nth-of-type(2) .card-title {
  /* Targeting the Documents card specifically */
  font-size: 1.6rem;
  /* Slightly larger title */
  font-weight: 700;
  /* Bolder */
  color: #263238;
  /* Darker, sophisticated grey */
  margin-bottom: 15px;
  padding-bottom: 10px;
  border-bottom: 2px solid #e0e0e0;
  /* Softer divider */
  display: flex;
  align-items: center;
}

.detail-card:nth-of-type(2) .card-title .v-icon {
  /* Targeting the Documents card title icon */
  margin-right: 12px;
  font-size: 2rem;
  /* Larger icon in title */
}

.document-list {
  background-color: #fcfcfc;
  /* Very light background */
  border-radius: 10px;
  padding: 8px 0;
  border: 1px solid #e0e0e0;
  /* Lighter border */
  max-height: 300px;
  overflow-y: auto;
}

.document-list-item {
  border-bottom: 1px solid #f0f0f0;
  /* Lighter divider */
  padding: 12px 20px;
  transition: background-color 0.2s;
  cursor: pointer;
  /* Indicate clickable */
}

.document-list-item:hover {
  background-color: #eef7ff;
  /* Lighter hover */
}

.document-name {
  font-size: 0.98rem;
  font-weight: 500;
  color: #424242;
  margin-left: 10px;
}

.action-button {
  margin: 0 5px;
  transition: transform 0.2s, color 0.2s;
}

.action-button:hover {
  transform: translateY(-1px);
}

.action-button .v-icon {
  font-size: 1.25rem;
  /* Slightly larger icons */
}

/* --- Activity Log (New Styles) --- */
.detail-card:nth-of-type(3) .card-title {
  /* Targeting the Activity Log card specifically */
  font-size: 1.6rem;
  /* Slightly larger title */
  font-weight: 700;
  /* Bolder */
  color: #263238;
  /* Darker, sophisticated grey */
  margin-bottom: 15px;
  padding-bottom: 10px;
  border-bottom: 2px solid #e0e0e0;
  /* Softer divider */
  display: flex;
  align-items: center;
}

.detail-card:nth-of-type(3) .card-title .v-icon {
  /* Targeting the Activity Log card title icon */
  margin-right: 12px;
  font-size: 2rem;
  /* Larger icon in title */
}

.activity-search-field {
  max-width: 100%;
}

.activity-timeline {
  padding-left: 20px;
}

.activity-timeline-item {
  padding-bottom: 25px;
  /* More space between items */
}

.activity-timeline-item::before {
  background-color: #e0e0e0 !important;
  /* Lighter line */
}

.activity-date {
  font-size: 0.8rem;
  color: #78909C;
  /* Softer date color */
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  user-select: none;
  font-weight: 500;
}

.activity-date:hover {
  color: #4d90fe;
}

.activity-content {
  background-color: #fefefe;
  padding: 18px;
  /* More padding */
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
  /* Softer shadow */
  margin-left: 15px;
  border-left: 4px solid #4d90fe;
  /* More prominent accent border */
}

.activity-action-by {
  font-size: 1.05rem;
  color: #37474F;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  font-weight: 600;
}

.activity-action-by .v-icon {
  margin-right: 8px;
  font-size: 1.2rem;
}

.activity-details {
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px dashed #e5e5e5;
  /* Lighter dashed line */
}

.activity-changes-label {
  color: #607D8B;
  font-weight: 600;
  font-size: 0.85rem;
}

.activity-details-list {
  list-style-type: none;
  padding-left: 0;
  font-size: 0.9rem;
  color: #607D8B;
  margin-top: 8px;
}

.activity-details-list li {
  margin-bottom: 6px;
  padding-left: 20px;
  position: relative;
}

.activity-details-list li::before {
  content: '•';
  position: absolute;
  left: 0;
  color: #4d90fe;
  font-size: 1.2em;
  /* Larger bullet */
  top: -2px;
}

.no-activity-details {
  display: flex;
  align-items: center;
  color: #90A4AE;
  font-style: italic;
}

.no-activity-details .v-icon {
  margin-right: 5px;
}

/* --- Messages & Chat (New Styles) --- */
.detail-card:nth-of-type(4) .card-title {
  /* Targeting the Messages & Chat card specifically */
  font-size: 1.6rem;
  /* Slightly larger title */
  font-weight: 700;
  /* Bolder */
  color: #263238;
  /* Darker, sophisticated grey */
  margin-bottom: 15px;
  padding-bottom: 10px;
  border-bottom: 2px solid #e0e0e0;
  /* Softer divider */
  display: flex;
  align-items: center;
}

.detail-card:nth-of-type(4) .card-title .v-icon {
  /* Targeting the Messages & Chat card title icon */
  margin-right: 12px;
  font-size: 2rem;
  /* Larger icon in title */
}

.section-subtitle {
  font-size: 1.3rem;
  /* Slightly larger */
  font-weight: 600;
  color: #263238;
  margin-bottom: 20px;
  padding-bottom: 8px;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  align-items: center;
}

.section-subtitle .v-icon {
  margin-right: 8px;
  font-size: 1.5rem;
}

.message-threads-list {
  max-height: 380px;
  /* Slightly taller */
  overflow-y: auto;
  border: 1px solid #e0e0e0;
  border-radius: 10px;
  background-color: #fff;
  padding: 5px;
}

.message-thread-item {
  border-bottom: 1px solid #f5f5f5;
  /* Very light divider */
  padding: 15px 15px;
  /* More padding */
  transition: all 0.2s;
  cursor: pointer;
  border-radius: 8px;
  /* Rounded items */
  margin-bottom: 5px;
}

.message-thread-item:last-child {
  border-bottom: none;
}

.message-thread-item:hover {
  background-color: #eef7ff;
}

.selected-message-thread {
  background-color: #e3f2fd !important;
  /* Lighter selected background */
  border-left: 4px solid #2196F3;
  /* Primary blue accent */
}

.message-subject {
  font-size: 1.05rem;
  color: #37474F;
  display: flex;
  align-items: center;
  font-weight: 600;
  margin-bottom: 5px;
}

.message-subject .v-icon {
  margin-right: 8px;
}

.message-preview {
  font-size: 0.9rem;
  color: #607D8B;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.message-date {
  font-size: 0.78rem;
  color: #90A4AE;
  margin-top: 5px;
}

.message-date .v-icon {
  margin-right: 4px;
}

.unread-chip {
  height: 22px;
  font-size: 0.75rem;
  margin-left: 10px;
  border-radius: 11px;
  font-weight: 700;
  background-color: #EF5350 !important;
  /* Brighter red */
  color: white !important;
}

/* Chat History */
.chat-history-list {
  max-height: 380px;
  overflow-y: auto;
  padding: 15px;
  background-color: #fcfcfc;
  border-radius: 10px;
  border: 1px solid #e0e0e0;
  display: flex;
  flex-direction: column;
}

.chat-bubble-item {
  margin-bottom: 15px;
  display: flex;
  width: 100%;
}

.my-message {
  justify-content: flex-end;
}

.other-message {
  justify-content: flex-start;
}

.my-message-content,
.other-message-content {
  padding: 12px 18px;
  border-radius: 20px;
  /* More rounded bubbles */
  max-width: 85%;
  /* Slightly wider messages */
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
  /* Softer shadow */
}

.my-message-content {
  background-color: #2196F3;
  /* Primary blue for sent messages */
  color: white;
  border-bottom-right-radius: 8px;
  /* Less rounded on one corner */
}

.other-message-content {
  background-color: #ECEFF1;
  /* Light grey for received messages */
  color: #37474F;
  border-bottom-left-radius: 8px;
}

.chat-sender {
  font-size: 0.9rem;
  margin-bottom: 4px;
  display: flex;
  align-items: center;
}

.chat-sender .v-icon {
  margin-right: 6px;
}

.chat-message-text {
  font-size: 0.95rem;
  word-wrap: break-word;
  color: inherit;
  /* Inherit color from bubble */
}

.chat-timestamp {
  font-size: 0.75rem;
  text-align: right;
  margin-top: 5px;
  opacity: 0.9;
}

.chat-timestamp .v-icon {
  margin-right: 4px;
}

/* Chat Input */
.chat-input-area {
  padding: 15px 0 0 0;
  display: flex;
  align-items: center;
}

.chat-text-field {
  flex: 1;
}

.send-button {
  background-color: #2196F3;
  /* Primary blue */
  color: white;
  margin-left: 10px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.send-button:hover {
  background-color: #1976D2;
  /* Darker blue on hover */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

/* No Data Message */
.no-data-message {
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  color: #90A4AE;
  /* Softer grey */
  font-style: italic;
  padding: 25px;
  /* More padding */
  background-color: #f7f7f7;
  /* Lighter background */
  border-radius: 10px;
  margin: 15px 0;
  border: 1px dashed #e0e0e0;
}

.no-data-message .v-icon {
  margin-right: 10px;
  font-size: 1.5rem;
  color: #B0BEC5;
  /* Icon color for no data */
}

/* Dialog Styles (Image/PDF Viewer) */
.dialog-title {
  background-color: #2196F3;
  color: white;
  font-weight: 600;
  padding: 16px 24px;
}

.pdf-dialog-fullscreen .v-card {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.pdf-viewer-container {
  flex-grow: 1;
  padding: 0;
}

/* Responsive Design */
@media (max-width: 960px) {
  .main-container {
    padding: 20px;
  }

  .detail-card {
    padding: 20px;
  }

  /* Original styling for first card title */
  .detail-card:first-of-type .card-title {
    font-size: 1.3rem;
  }

  /* Original styling for first card detail items */
  .detail-card:first-of-type .detail-item strong {
    min-width: 120px;
  }

  /* New styling for other card titles */
  .detail-card:nth-of-type(2) .card-title,
  .detail-card:nth-of-type(3) .card-title,
  .detail-card:nth-of-type(4) .card-title {
    font-size: 1.4rem;
  }

  .section-subtitle {
    font-size: 1.15rem;
  }
}

@media (max-width: 600px) {
  .main-container {
    padding: 15px;
  }

  .detail-card {
    padding: 15px;
  }

  /* Original styling for first card title */
  .detail-card:first-of-type .card-title {
    font-size: 1.2rem;
  }

  /* Original styling for first card detail items */
  .detail-card:first-of-type .detail-item strong {
    min-width: 100%;
    margin-bottom: 3px;
  }

  .detail-card:first-of-type .detail-value {
    min-width: 100%;
  }

  .detail-column {
    padding: 0 10px;
  }

  .activity-content {
    margin-left: 10px;
    padding: 12px;
  }

  .chat-history-list {
    padding: 10px;
  }

  .my-message-content,
  .other-message-content {
    max-width: 95%;
  }

  /* New styling for other card titles */
  .detail-card:nth-of-type(2) .card-title,
  .detail-card:nth-of-type(3) .card-title,
  .detail-card:nth-of-type(4) .card-title {
    font-size: 1.25rem;
    flex-direction: column;
    align-items: flex-start;
  }

  .detail-card:nth-of-type(2) .card-title .v-icon,
  .detail-card:nth-of-type(3) .card-title .v-icon,
  .detail-card:nth-of-type(4) .card-title .v-icon {
    margin-right: 0;
    margin-bottom: 8px;
    font-size: 1.8rem;
  }

  .section-subtitle {
    font-size: 1.05rem;
    flex-direction: column;
    align-items: flex-start;
  }

  .section-subtitle .v-icon {
    margin-right: 0;
    margin-bottom: 5px;
    font-size: 1.3rem;
  }
}
</style>