<template>
    <v-container class="px-10 hmmsdashboard" fluid style="height:100vh;">
        <v-breadcrumbs :items="breadcrumbs" class="breadcrumbs-container">
            <template v-slot:divider>
                <v-icon color="white">mdi-chevron-right</v-icon>
            </template>
            <template v-slot:item="{ item }">
                <v-breadcrumbs-item :href="item.href" :disabled="item.disabled" class="custom-breadcrumb-item">
                    {{ item.text.toUpperCase() }}
                </v-breadcrumbs-item>
            </template>
        </v-breadcrumbs>

        <div class="text-h6 mb-4 mt-6 dashboard-title">
            USER ACTIVITY
        </div>

        <Transition name="slide-fade">
            <div class="mt-4 mb-2 filter-container">
                <v-row>
                    <v-col cols="12" md="4">
                        <v-text-field v-model="search" label="Search by name or mobile" clearable @input="filterClient"
                            prepend-inner-icon="mdi-magnify" dense outlined />
                    </v-col>

                    <v-col cols="12" md="2" class="button-group">

                        <v-menu open-on-hover>
                            <template v-slot:activator="{ props }">
                                <v-btn v-bind="props" class="export-btn ml-2"
                                    style="background: linear-gradient(45deg, #4d90fe, #285bc7); color: white;">
                                    Export
                                </v-btn>
                            </template>
                            <v-list class="export-menu" style="cursor: pointer">

                                <v-list-item @click="toCSV">
                                    <v-list-item-title>CSV</v-list-item-title>
                                </v-list-item>

                                <v-list-item>
                                    <v-list-item-title @click="toPdf()">PDF</v-list-item-title>
                                </v-list-item>
                            </v-list>
                        </v-menu>
                    </v-col>
                </v-row>
            </div>
        </Transition>

        <v-table class="rounded-lg mt-6 modern-table">
            <thead>
                <tr>
                    <th class="text-left">#</th>
                    <th class="text-left">NAME</th>
                    <th class="text-left">MOBILE</th>
                    <!-- <th class="text-left">DETAILS</th> -->
                    <th class="text-left">ACTION</th>
                    <th class="text-left">TIME</th>
                    <!-- <th class="text-left">action</th> -->
                    <th class="text-left">CREATED DATE</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(item, i) in UserLogs" :key="item.username" class="table-row-hover">
                    <td>{{ i + 1 }}</td>
                    <td>{{ item.user.username }}</td>
                    <td>{{ item.user.mobile }}</td>
                    <!-- <td>{{ item.details }}</td> -->
                    <td>{{ item.action }}</td>
                    <td>{{ item.timestamp ? item.timestamp.split('T')[0] : 'N/A' }}</td>
                    <!-- <td>{{ item.clientaction.client_action }}</td> -->
                    <td>{{ item.createdAt ? item.createdAt.split('T')[0] : 'N/A' }}</td>
                </tr>
            </tbody>
        </v-table>

        <!-- <paginationVue :length="clientTotalPage" @changePage="changePage" class="pagination" /> -->
        <v-pagination v-model="page" :length="totalPages" :total-visible="7" color="primary" class="mt-4"
            @update:modelValue="changePage" />

    </v-container>
</template>

<script>
import { mapActions, mapState } from 'vuex';
import paginationVue from '@/components/pagination.vue';
import jsPDF from "jspdf";
import autoTable from 'jspdf-autotable';

export default {
    name: 'UserLogs',
    components: {
        paginationVue,
    },
    data() {
        return {
            breadcrumbs: [
                { text: 'Home', disabled: false, href: '/' },
                { text: 'USER ACTIVITY', disabled: true, href: '/UserLog' },
            ],
            username: '',
            mobile: '',
            action: '',
            timestamp: '',
            createdAt: '',
            search: '',
            json_data: [],
            page: 1,
            size: 15,
            totalPages: 1,
        }
    },
    computed: {
        ...mapState('user', ['UserLogs']),
    },
    methods: {
        ...mapActions('user', ['GET_USERLOG_LIST']),

  toCSV() {
            const data = this.UserLogs.map(el => ({
                'NAME': el.user?.username || 'N/A',
                'MOBILE': el.user?.mobile || 'N/A',
                'ACTION': el.action || 'N/A',
                'TIME': el.timestamp || 'N/A',
                'CREATED DATE': el.createdAt ? el.createdAt.split('T')[0] : 'N/A',
            }));

            if (data.length === 0) {
                this.snackColor = 'error';
                this.snacKtext = 'No data available to export';
                this.snackbar = true;
                return;
            }

            const headers = Object.keys(data[0]);
            const csvContent = [
                headers.join(','),
                ...data.map(row => headers.map(h => `"${row[h]}"`).join(','))
            ].join('\n');

            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.setAttribute('download', 'UserActivity.csv');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        },


      
        toPdf() {
    try {
       
        const logs = this.UserLogs;

        if (!logs || !Array.isArray(logs) || logs.length === 0) {
            alert('No data available to generate PDF.');
            return;
        }

        const doc = new jsPDF();

        // Simple title
        doc.setFontSize(16);
        doc.text('User Activity Report', 20, 20);

        // Simple table data
        const tableData = logs.map((item, index) => [
            index + 1,
            item.user?.username || 'N/A',
            item.user?.mobile || 'N/A',
            item.action || 'N/A',
            item.timestamp ? item.timestamp.split('T')[0] : 'N/A',
            item.createdAt ? item.createdAt.split('T')[0] : 'N/A'
        ]);

        // Create table
        autoTable(doc, {
            head: [['#', 'Name', 'Mobile', 'Action', 'Time', 'Created Date']],
            body: tableData,
            startY: 30,
            styles: { fontSize: 8 },
            headStyles: { fillColor: [77, 144, 254] }
        });

        doc.save('UserActivityReport.pdf');
        
    } catch (error) {
        console.error('PDF Error:', error);
        alert('PDF generation failed: ' + error.message);
    }
},

        filterClient() {
            this.page = 1;
            const payload = {
                page: this.page,
                size: this.size,
                username: this.username || '',
                action: this.action || '',
                mobile: this.mobile || '',
                timestamp: this.timestamp || '',
                createdAt: this.createdAt || '',
                search: this.search || '',
            };
            this.GET_USERLOG_LIST(payload).then(response => {
                this.totalPages = response.totalPages;
            });
        },
        changePage(pageNumber) {
            this.page = pageNumber;
            const query = {
                page: this.page,
                size: this.size,
                username: this.username || '',
                action: this.action || '',
                mobile: this.mobile || '',
                timestamp: this.timestamp || '',
                createdAt: this.createdAt || '',
            };
            this.GET_USERLOG_LIST(query).then(response => {
                this.totalPages = response.totalPages; 
            });
        }

    },

    mounted() {
        this.GET_USERLOG_LIST({ page: this.page, size: this.size }).then(response => {
            this.totalPages = response.totalPages;
        }).catch(error => {
            console.error('Error during initialization:', error);
        });
    }

}
</script>

<style scoped>

.hmmsdashboard {
    background: linear-gradient(135deg, #F5F7FA, #E8ECEF);
    min-height: 100vh;
    padding: 20px;
    color: #1F2937;
}

/* Breadcrumb Styling */
.breadcrumbs-container {
    background: linear-gradient(90deg, #4d90fe, #285bc7);
    border-radius: 12px;
    padding: 10px 16px;
    box-shadow: 0 6px 15px rgba(77, 144, 254, 0.2);
    animation: slideInDown 0.8s ease-out;
}

.custom-breadcrumb-item {
    color: #FFFFFF;
    font-weight: 700;
    font-size: 1rem;
    transition: all 0.3s ease;
}

.custom-breadcrumb-item:hover {
    color: #E5E7EB;
    transform: scale(1.05);
}

/* Dashboard Title */
.dashboard-title {
    font-family: 'Montserrat', sans-serif;
    font-size: 1.8rem;
    font-weight: 800;
    background: linear-gradient(45deg, #4d90fe, #285bc7);
    -webkit-background-clip: text;
    color: transparent;
    animation: slideInLeft 0.8s ease-out;
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
}

/* Filter Container */
.filter-container {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 4px 12px rgba(77, 144, 254, 0.2);
    animation: fadeIn 0.8s ease-out;
}

/* Filter Inputs */
.filter-input /deep/ .v-input__control {
    border-radius: 6px;
    background: rgba(255, 255, 255, 0.9);
    transition: all 0.3s ease;
}

.filter-input /deep/ .v-input__control:hover {
    background: rgba(245, 247, 250, 0.95);
    box-shadow: 0 2px 8px rgba(77, 144, 254, 0.2);
}

/* Buttons */
.button-group {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    gap: 8px;
    height: 100%;
}

.filter-btn,
.export-btn {
    border-radius: 6px;
    transition: all 0.3s ease;
    text-transform: none;
    font-weight: 600;
}

.filter-btn:hover,
.export-btn:hover {
    transform: scale(1.05);
    box-shadow: 0 4px 12px rgba(77, 144, 254, 0.3);
}

/* Export Menu */
.export-menu {
    background: #285bc7;
    color: #4d90fe;
    border-radius: 6px;
}

.export-menu .v-list-item:hover {
    background: rgba(255, 255, 255, 0.1);
}

/* Table Styling (Unchanged) */
.modern-table {
    background: white;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    border-radius: 8px;
}

.modern-table th {
    background: #042B4C;
    color: white !important;
    padding: 12px;
    font-weight: 600;
}

.table-row-hover:hover {
    background: #f5f7fa;
}

.v-table tbody tr td {
    padding: 12px;
    border-bottom: 1px solid #eee;
}

.v-table {
    font-family: 'Montserrat', sans-serif;
}

/* Pagination */
.pagination {
    margin-top: 16px;
    animation: fadeInUp 0.8s ease-out;
}

/* CSS Keyframe Animations */
@keyframes slideInDown {
    0% {
        opausername: 0;
        transform: translateY(-100%);
    }

    100% {
        opausername: 1;
        transform: translateY(0);
    }
}

@keyframes slideInLeft {
    0% {
        opausername: 0;
        transform: translateX(-100px);
    }

    100% {
        opausername: 1;
        transform: translateX(0);
    }
}

@keyframes fadeInUp {
    0% {
        opausername: 0;
        transform: translateY(50px);
    }

    100% {
        opausername: 1;
        transform: translateY(0);
    }
}

@keyframes fadeIn {
    0% {
        opausername: 0;
    }

    100% {
        opausername: 1;
    }
}

/* Responsive Design */
@media (max-width: 960px) {
    .hmmsdashboard {
        padding: 12px;
    }

    .dashboard-title {
        font-size: 1.5rem;
    }

    .breadcrumbs-container {
        padding: 8px 12px;
    }

    .custom-breadcrumb-item {
        font-size: 0.9rem;
    }

    .filter-container {
        padding: 15px;
    }

    .modern-table {
        margin-top: 12px;
        display: block;
        overflow-x: auto;
        white-space: nowrap;
    }

    .modern-table th,
    .modern-table td {
        padding: 10px 6px;
        font-size: 0.8rem;
    }

    .pagination {
        margin-top: 12px;
    }
}

@media (max-width: 600px) {
    .hmmsdashboard {
        padding: 8px;
    }

    .dashboard-title {
        font-size: 1.2rem;
    }

    .breadcrumbs-container {
        padding: 6px 10px;
    }

    .custom-breadcrumb-item {
        font-size: 0.8rem;
    }

    .filter-container {
        padding: 10px;
    }

    .filter-btn,
    .export-btn {
        font-size: 0.8rem;
        padding: 6px 12px;
    }

    .modern-table {
        margin-top: 10px;
    }

    .modern-table th,
    .modern-table td {
        padding: 8px 4px;
        font-size: 0.7rem;
    }

    .pagination {
        margin-top: 10px;
    }
}
</style>

<style>
.slide-fade-enter-active {
    transition: all 0.3s ease-out;
}

.slide-fade-leave-active {
    transition: all 0.2s cubic-bezier(1, 0.5, 0.8, 1);
}

.slide-fade-enter-from,
.slide-fade-leave-to {
    transform: translateX(20px);
    opausername: 0;
}
</style>